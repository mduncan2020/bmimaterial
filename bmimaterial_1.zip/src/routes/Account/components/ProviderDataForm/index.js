import ProviderDataForm from './ProviderDataForm'

export default ProviderDataForm
