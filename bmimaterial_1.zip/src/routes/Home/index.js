import { HOME_PATH as path } from 'constants'
import HomeContainer from './containers/HomeContainer'

// Sync route definition
export default {
  path,
  component: HomeContainer
}
