import React, { Component, PropTypes } from 'react'
import IconButton from 'material-ui/IconButton'
import Dialog from 'material-ui/Dialog';
import FloatingActionButton from 'material-ui/FloatingActionButton';
import FlatButton from 'material-ui/FlatButton';
import Paper from 'material-ui/Paper'
import TextField from 'material-ui/TextField'
import ContentAdd from 'material-ui/svg-icons/content/add'
import Subheader from 'material-ui/Subheader'
import classes from './NewTodoPanel.scss'
import { required, validateNumber } from 'utils/forms'
import { Field, reduxForm, submit } from 'redux-form'
import { ADD_RECORD_FORM_NAME } from 'constants'

class NewTodoPanel extends Component {
  static propTypes = {
    onNewClick: PropTypes.func,
    disabled: PropTypes.bool
  }

  constructor(props){
    super(props);

    this.state = {
            styles: {
                    addButton: {
                        marginTop: 10,
                        marginLeft: 20
                    }                                     
            },            
            addDialogOpen: false
        }

      this.onHandleDialogClose = this.onHandleDialogClose.bind(this);
      this.onHandleDialogOpen = this.onHandleDialogOpen.bind(this);
      this.submitForm = this.submitForm.bind(this);
  }

  onHandleDialogOpen() {
    this.setState({addDialogOpen: true})
  }

  onHandleDialogClose() {
      this.setState({addDialogOpen: false})
  }

  handleAdd = () => {
    console.log('handleAdd')
    const { newWeight } = this.refs;
    const { weight } = this.state;
    this.props.onNewClick({ weight, done: false });
    newWeight.value = '';
     this.setState({addDialogOpen: false});
  }

  submitForm(){
    submit(ADD_RECORD_FORM_NAME);
  }

  render () {
    const { disabled } = this.props

    return (
      <span>
            <FloatingActionButton className={classes.addButton} onTouchTap={this.onHandleDialogOpen} tooltip={disabled ? 'Login To Add Weight' : 'Add Weight Record'}>
                <ContentAdd />
            </FloatingActionButton>   
            
              <Dialog title="New record" 
                        modal={false} 
                        open={this.state.addDialogOpen} 
                        onRequestClose={this.onHandleDialogClose} 
                        className={classes.container}
                        actions={
                            [<FlatButton label="Cancel" secondary={true} onTouchTap={this.onHandleDialogClose} />,
                            <FlatButton label="Save" primary={true} type='submit' onTouchTap={this.handleAdd}  />
                            ]
                        }>
                
                <div className={classes.inputSection}>
                  <form onSubmit={this.handleAdd}>      
                    <Field
                      name='newWeight'
                      ref='newWeight'
                      component={TextField}
                      label='New Weight'
                      onChange={({ target }) => this.setState({weight: Number(target.value)})}
                      validate={[required, validateNumber]}
                    />                  
                  
                  <div className={classes.submit}>
                    <FlatButton label="Cancel" secondary={true} onTouchTap={this.onHandleDialogClose} />
                    <FlatButton label="Save" primary={true} type='submit' onTouchTap={this.submitForm} />
                  </div>
                </form>
                </div>
              </Dialog>
            
      </span>
    )
  }
}


export default reduxForm({
  form: ADD_RECORD_FORM_NAME
})(NewTodoPanel)

/*
<TextField
                floatingLabelText='New Weight'
                ref='newWeight'
                onChange={({ target }) => this.setState({weight: Number(target.value)})}
              />
*/

/*
<Paper className={classes.container}>
            <Subheader>New Todo</Subheader>
            <div className={classes.inputSection}>
              <TextField
                floatingLabelText='New Todo Text'
                ref='newTodo'
                onChange={({ target }) => this.setState({text: target.value})}
              />
              <IconButton
                onClick={this.handleAdd}
                disabled={disabled}
                tooltipPosition='top-center'
                tooltip={disabled ? 'Login To Add Todo' : 'Add Todo'}
              >
                <ContentAdd />
              </IconButton>
            </div>
          </Paper>
 */