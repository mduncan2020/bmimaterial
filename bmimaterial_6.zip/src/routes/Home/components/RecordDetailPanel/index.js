import RecordDetailPanel from './RecordDetailPanel'

export default RecordDetailPanel
