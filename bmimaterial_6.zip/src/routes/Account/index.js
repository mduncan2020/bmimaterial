import { ACCOUNT_PATH as path } from 'constants'
import component from './containers/AccountContainer'

export default {
  path,
  component
}
