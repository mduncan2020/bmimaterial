import { SIGNUP_PATH as path } from 'constants'
import component from './containers/SignupContainer'

export default {
  path,
  component
}
