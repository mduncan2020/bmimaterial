import React, { Component, PropTypes } from 'react'
import classes from './TodoItem.scss'
import { ListItem } from 'material-ui/List'
import Delete from 'material-ui/svg-icons/action/delete-forever'
import Edit from 'material-ui/svg-icons/content/create'
import { isObject } from 'lodash'

import IconButton from 'material-ui/IconButton'
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import TextField from 'material-ui/TextField';
import DatePicker from 'material-ui/DatePicker';
import { required, validateNumber, minValue1 } from 'utils/forms'
import { Field, reduxForm, submit } from 'redux-form'
import { RECORD_FORM_NAME } from 'constants'

class TodoItem extends Component {
  static propTypes = {
    todo: PropTypes.object.isRequired,
    id: PropTypes.oneOfType([
      PropTypes.string,
      PropTypes.number
    ]),
    onDeleteClick: PropTypes.func
  }

  constructor(props){
    super(props);

    this.state = {
            dialogOpen: false
        }

      this.onHandleDialogClose = this.onHandleDialogClose.bind(this);
      this.onHandleDialogOpen = this.onHandleDialogOpen.bind(this);
      this.submitForm = this.submitForm.bind(this);
      this.renderWeightField = this.renderWeightField.bind(this);
      this.renderDateField = this.renderDateField.bind(this);

      console.log('record')
  }

  onEditClick(){
    this.setState({dialogOpen: true})
  }

  onHandleDialogOpen() {
    this.setState({dialogOpen: true})
  }

  onHandleDialogClose() {
      this.setState({dialogOpen: false})
  }

  handleSave = () => {    
    const { newWeight } = this.refs;
    const { weight } = this.state;
    this.props.onSaveClick({ weight, done: false });
    newWeight.value = '';
     this.setState({dialogOpen: false});
  }

  submitForm(){
    submit(RECORD_FORM_NAME);
  }

  renderWeightField(){
    return <TextField
                floatingLabelText='New weight'      
                type='number'      
                className={classes.input}
                onChange={({ target }) => this.setState({weight: Number(target.value)})}
                value={this.props.todo.weight}
              />;
  }

  renderDateField(){
    return <DatePicker 
              floatingLabelText="New date" 
              hintText="Date" 
              container="inline" 
              mode="landscape" 
              value={new Date(this.props.todo.createdAt)}/>;
  }

  render () {
    const { todo, id, onDeleteClick } = this.props

    return (
      <div className={classes.container}>
        <ListItem         
          rightIcon={
            <span>            
              <Edit onClick={() => this.onEditClick(todo._key || id)} />
              <Delete onClick={() => onDeleteClick(todo._key || id)} />
            </span>
          }
          primaryText={ todo.weight === undefined ? todo.text : todo.weight }   
          secondaryText={
            <p>
              <span className='TodoItem-Text'>
                Created: { new Date(todo.createdAt).toDateString() }
              </span>
            </p>
          }
          secondaryTextLines={2}
        />

        <Dialog title="Record" 
                    modal={false} 
                    open={this.state.dialogOpen} 
                    onRequestClose={this.onHandleDialogClose} 
                    className={classes.container}
                    actions={[]}>            
            
                <form onSubmit={this.handleSave} className={classes.form}>      
                    <Field
                        name='newWeight'
                        type='number'                      
                        component={this.renderWeightField}
                        label='Weight'                      
                        validate={[required, validateNumber,minValue1]}
                        warn={minValue1}
                    />  
                    <Field
                        name='newDate'                                                       
                        component={this.renderDateField}
                        label='Date'                      
                        validate={[required]}                        
                    />                  
                    
                    <div >
                        <FlatButton label="Cancel" secondary={true} onTouchTap={this.onHandleDialogClose} />
                        <FlatButton label="Save" primary={true} type='submit' onTouchTap={this.submitForm} />
                    </div>
                </form>
            
            </Dialog>
      </div>
    )
  }
}


export default reduxForm({
  form: RECORD_FORM_NAME
})(TodoItem)

/*
 leftIcon={
            <Checkbox
              defaultChecked={todo.done}
              onCheck={() => onCompleteClick(todo, todo._key || id)}
            />
          }


          <br />
              <span className='TodoItem-Owner'>
                Owner: {
                  isObject(todo.owner)
                  ? todo.owner.displayName || todo.owner.username
                  : todo.owner || 'No Owner'
                }
              </span>
 */