import { LOGIN_PATH as path } from 'constants'
import component from './containers/LoginContainer'

export default {
  path,
  component
}
