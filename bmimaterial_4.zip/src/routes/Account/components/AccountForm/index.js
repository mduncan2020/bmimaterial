import AccountForm from './AccountForm'

export default AccountForm
